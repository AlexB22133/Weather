package com.example.weatherappjava.network;

public class Network
{
    public static String openWeahterAPI = "http://api.weatherapi.com/v1/";

    public static String getOpenWeahterAPIKEY = "b13d3eb95f91424290932429233003";
}
